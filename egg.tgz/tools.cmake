# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(differential-fuzz src/differential-fuzz.cpp)
set_property(TARGET differential-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(differential-fuzz lionss pthread)

add_executable(werror-build src/werror-build.cpp)
set_property(TARGET werror-build PROPERTY CXX_STANDARD 11)
target_link_libraries(werror-build lionss pthread)

add_executable(snapshot-tests src/snapshot-tests.cpp)
set_property(TARGET snapshot-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(snapshot-tests lionss pthread)

add_executable(fuzz-corpus src/fuzz-corpus.cpp)
set_property(TARGET fuzz-corpus PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-corpus lionss pthread)

add_executable(cxx20-modules src/cxx20-modules.cpp)
set_property(TARGET cxx20-modules PROPERTY CXX_STANDARD 11)
target_link_libraries(cxx20-modules lionss pthread)

add_executable(ipc-bench src/ipc-bench.cpp)
set_property(TARGET ipc-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(ipc-bench lionss pthread)

add_executable(split-dwarf src/split-dwarf.cpp)
set_property(TARGET split-dwarf PROPERTY CXX_STANDARD 11)
target_link_libraries(split-dwarf lionss pthread)

add_executable(simd-throughput src/simd-throughput.cpp)
set_property(TARGET simd-throughput PROPERTY CXX_STANDARD 11)
target_link_libraries(simd-throughput lionss pthread)

add_executable(flamegraph src/flamegraph.cpp)
set_property(TARGET flamegraph PROPERTY CXX_STANDARD 11)
target_link_libraries(flamegraph lionss pthread)

add_executable(macos-universal src/macos-universal.cpp)
set_property(TARGET macos-universal PROPERTY CXX_STANDARD 11)
target_link_libraries(macos-universal lionss pthread)

add_executable(meson-build src/meson-build.cpp)
set_property(TARGET meson-build PROPERTY CXX_STANDARD 11)
target_link_libraries(meson-build lionss pthread)

add_executable(perf-stat src/perf-stat.cpp)
set_property(TARGET perf-stat PROPERTY CXX_STANDARD 11)
target_link_libraries(perf-stat lionss pthread)

add_executable(build-shared src/build-shared.cpp)
set_property(TARGET build-shared PROPERTY CXX_STANDARD 11)
target_link_libraries(build-shared lionss pthread)

add_executable(dead-code-scan src/dead-code-scan.cpp)
set_property(TARGET dead-code-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dead-code-scan lionss pthread)

add_executable(uclibc-build src/uclibc-build.cpp)
set_property(TARGET uclibc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(uclibc-build lionss pthread)

add_executable(wasi-build src/wasi-build.cpp)
set_property(TARGET wasi-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-build lionss pthread)

add_executable(gcc-trunk src/gcc-trunk.cpp)
set_property(TARGET gcc-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-trunk lionss pthread)

add_executable(symbol-count src/symbol-count.cpp)
set_property(TARGET symbol-count PROPERTY CXX_STANDARD 11)
target_link_libraries(symbol-count lionss pthread)

add_executable(false-sharing src/false-sharing.cpp)
set_property(TARGET false-sharing PROPERTY CXX_STANDARD 11)
target_link_libraries(false-sharing lionss pthread)

add_executable(linux-armhf src/linux-armhf.cpp)
set_property(TARGET linux-armhf PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armhf lionss pthread)

add_executable(endianness-check src/endianness-check.cpp)
set_property(TARGET endianness-check PROPERTY CXX_STANDARD 11)
target_link_libraries(endianness-check lionss pthread)

add_executable(package-snap src/package-snap.cpp)
set_property(TARGET package-snap PROPERTY CXX_STANDARD 11)
target_link_libraries(package-snap lionss pthread)

add_executable(man-pages src/man-pages.cpp)
set_property(TARGET man-pages PROPERTY CXX_STANDARD 11)
target_link_libraries(man-pages lionss pthread)

add_executable(dast-scan src/dast-scan.cpp)
set_property(TARGET dast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dast-scan lionss pthread)

add_executable(mocked-tests src/mocked-tests.cpp)
set_property(TARGET mocked-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(mocked-tests lionss pthread)

add_executable(clang-latest src/clang-latest.cpp)
set_property(TARGET clang-latest PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-latest lionss pthread)

add_executable(offline-tests src/offline-tests.cpp)
set_property(TARGET offline-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(offline-tests lionss pthread)

add_executable(timeout-tests src/timeout-tests.cpp)
set_property(TARGET timeout-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timeout-tests lionss pthread)

add_executable(cache-warmup src/cache-warmup.cpp)
set_property(TARGET cache-warmup PROPERTY CXX_STANDARD 11)
target_link_libraries(cache-warmup lionss pthread)

add_executable(build-release src/build-release.cpp)
set_property(TARGET build-release PROPERTY CXX_STANDARD 11)
target_link_libraries(build-release lionss pthread)

