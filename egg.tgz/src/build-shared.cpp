// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("build shared\n", stdout);
  return lionss_run_workload("build-shared");
}
