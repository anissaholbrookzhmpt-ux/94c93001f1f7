// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("false sharing\n", stdout);
  return lionss_run_workload("false-sharing");
}
