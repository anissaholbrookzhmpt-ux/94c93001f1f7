// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("snapshot tests"); }
int main(){
  announce();
  return lionss_run_workload("snapshot-tests");
}
