// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("mocked tests\n", stdout);
  return lionss_run_workload("mocked-tests");
}
